# Lane: ARCH.pl reconcile (3 stale rows)

You are a mechanical lane worker. Execute exactly as written. If reality
deviates from anything stated here, STOP and write what you saw into
REPORT.md. Do not improvise.

## Base verification (FIRST action)
```bash
cd /Users/chrishafley/projects/sprefa-reconcile-flash
git merge --ff-only 92756b54dc0cb633e9636234f5358f3324be1ebf
git rev-parse HEAD
```
Must print 92756b54dc0cb633e9636234f5358f3324be1ebf. If not: STOP, report.

## Ownership
You may modify ONLY `v6/prolog/ARCH.pl` and create `REPORT.md` at the
worktree root. Commit your ARCH.pl change with message
`ARCH reconcile: 811+812 stale unbuilt -> done, 813 comment corrected`.
Never push.

## Evidence (verified by the coordinator today; context, not instructions)
- Row ~811 `task(group_concat_silent_miscompile, unbuilt, [])` is stale:
  row ~836 oracle_body_gate made group_concat refuse(not_implemented), and
  row ~875 ordered_aggregate_arc (done, landed 2026-07-30) shipped
  group_concat/2 + /3 and json_group_array; row ~842 devlog_rail dogfoods
  group_concat in production.
- Row ~812 `task(host_column_shadows_runtime, unbuilt, [])` is stale: the
  load-time refusal shipped in commit 54dc7604 "hosts: refuse a host column
  that shadows a runtime column" and fires today (the 6-ordinal.dl6 lab
  fixture trips it: compiler refused rule 'host_column_shadows_runtime').
- Row ~813 `task(staged_writes_lab, done, [])` comment contains "no string
  aggregate available", stale for the same reason as 811.

## Edits (exact)
1. In the line beginning `task(group_concat_silent_miscompile,` change the
   status word `unbuilt` to `done` and append to the END of that line's
   comment:
   ` RECONCILED 2026-08-02: superseded by oracle_body_gate (refuse not_implemented) then ordered_aggregate_arc (done 2026-07-30): group_concat/2,/3 + json_group_array shipped; devlog_rail dogfoods it. Not reproducible as filed.`
2. In the line beginning `task(host_column_shadows_runtime,` change the
   status word `unbuilt` to `done` and append to the END of that line's
   comment:
   ` RECONCILED 2026-08-02: refusal shipped in 54dc7604 and fires today; 6-ordinal.dl6 (staged-writes lab fixture) predates it and now trips the refusal in receipts.sh phase 0 -- fixture update is a SEPARATE unowned task.`
3. In the line beginning `task(staged_writes_lab,` append to the END of the
   comment:
   ` RECONCILE NOTE 2026-08-02: "no string aggregate available" was true when graded and is stale since ordered_aggregate_arc landed group_concat the same day.`

Do not change any other line. Do not reflow or rewrap existing text.

## Validation (run after editing, before committing)
```bash
cd v6/prolog && swipl -g go -t halt ARCH.pl; echo "exit=$?"
```
Every check line must say PASS and exit=0. If any check fails: revert your
edit (`git checkout -- ARCH.pl`), do NOT commit, and paste the failing
output into REPORT.md.

## REPORT.md skeleton
```
# Reconcile REPORT
## Base sha verified: <yes/no>
## Edits applied: <1,2,3 or which failed>
## Gate output: <paste full swipl output + exit>
## Commit: <sha or "not committed" + why>
## Deviations: <or "none">
```
