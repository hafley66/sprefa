# Lane: research — common sqlite schema + generated rs/ts types (history mine)

You are a research lane worker. Produce RESEARCH.md at the worktree root.
Every claim MUST carry a file path (and line where useful). No claim without
a path. If a listed path does not exist, record that fact and move on — do
not improvise substitutes. Never commit or push.

## Base verification (FIRST action)
```bash
cd /Users/chrishafley/projects/sprefa-research-schema
git merge --ff-only 92756b54dc0cb633e9636234f5358f3324be1ebf && git rev-parse HEAD
```
Must print 92756b54dc0cb633e9636234f5358f3324be1ebf. If not: STOP, report.

## Ownership
Create ONLY `RESEARCH.md` and `research-notes/`. Everything else read-only.
Directories outside this worktree (listed below) are READ-ONLY reference.

## The proposal being researched (context)
sprefa-extract exports ONE canonical sqlite schema definition; the dl6
toolchain generates the loading types/interfaces from it for BOTH rust and
typescript, so the db-loading seam is generated not hand-kept. Suspected
dogfood precedent: early v6 runtime tools written against rusqlite that were
later ported to typescript. The user says this idea has come up before in
this repo's plans/chat logs. Your job: find every prior appearance, every
existing schema definition site, every codegen precedent, and the TypeSpec
prior art, so a decision doc can be written on top.

## Search program (execute all, capture findings with paths)

### A. Schema definition sites (where sqlite DDL / row shapes live today)
- `v6/sprefa-extract/src/schema.rs`, `rows.rs`, `wire.rs`, `types.rs`,
  `scip_v5_rels.rs` — what schema/row vocabulary does extract own?
- `v6/sprefa-store/src/` (rust) AND `v6/sprefa-store/js/src/` (ts): both
  exist. Find matching/parallel type definitions between the two — actual
  named pairs (rust struct vs ts interface). `js/src/engine/types.ts` and
  `js/src/lower/types.ts` are declared header files.
- `v6/dl/src/0_types.ts`, `2_schema.ts` if present; `v6/tsv2/runtime/`.
- grep all of the above for `CREATE TABLE` and record every occurrence site.

### B. The rust->ts port history (the dogfood precedent)
- `git log --oneline --all -i --grep="port"` and `--grep="rusqlite"` and
  `--grep="js runtime"` in this worktree; record commits naming a rust->ts
  port of store/runtime tools.
- Compare `v6/sprefa-store/src/` vs `v6/sprefa-store/js/src/` module names
  side by side; produce the port map table (rust file -> ts file -> drifted?).

### C. Prior discussion of this exact idea
- `grep -rn -il "schema.*gen\|generate.*types\|codegen\|typespec" plans/ | head -30`
  then read the hits; record date-ordered timeline rows.
- `v6/prolog/ARCH.pl`: rows `schema_import_epic` (~751), the `prior_art`
  line mentioning hafley_tsp (~203), `openapi_codegen_spine` (~800),
  `json_interop_lab` (~778). Quote each row's relevant clause.
- `chat_log/`: grep for typespec/codegen/schema-gen mentions, list hits with
  dates. Same for `v6/plans/` and `v6/findings/` if present.
- `plans/2026-06-18-north-star-types-modules-parsers.md` — read fully,
  summarize its relationship to this proposal.

### D. TypeSpec prior art (READ-ONLY, outside repo) — BOUNDED, 10 min max
- `~/projects/hafley-tsp/`: read ONLY these: AGENTS.md, README.md,
  monomorphization-engine.md, `ls docs/ examples/ src/`. NEVER grep or walk
  the whole dir — it contains node_modules and killed the previous lane.
  Any grep MUST carry `--glob '!node_modules'` or target a single file.
- `~/projects/claude-research/`:
  `rg -il typespec ~/projects/claude-research -g '*.md' -g '!node_modules' | head -20`
  then read at most the top 3 hits' first 50 lines each.

### E. Codegen precedents already in-repo
- `v6/prolog/src/emit_ts.pl` + `emit_ts.pl` at prolog root — prolog emits ts
  today. Note entry points.
- `openapi_codegen_spine` artifacts: find where its 5-routes/14-schemas
  generation lives (grep plans/ and v6/prolog for openapi).
- `v6/prolog/compile/1_emit_registry_docs.pl`, `2_emit_cli_inventory.pl` —
  doc-emitters as precedent.

## RESEARCH.md required structure
1. **Timeline** — date-ordered table: date | artifact path | what was said or
   decided relevant to schema/type generation.
2. **Schema-site inventory** — every place a row shape or CREATE TABLE is
   defined today: path | what it defines | rust/ts/prolog | hand-kept or
   generated.
3. **Port map** — rust module -> ts module pairs in sprefa-store (and
   anywhere else found), with a drifted/faithful judgment per pair based on
   name + signature comparison only.
4. **TypeSpec assets** — hafley-tsp + claude-research inventory rows.
5. **Codegen precedents** — what already generates code/docs from facts.
6. **Gaps** — what the proposal needs that nothing listed provides.
7. **Contradictions** — anything found that argues AGAINST the proposal or
   records a past decision to NOT do this.

Terse. Tables over prose. Paths on every row.
