# Lane A: effect_cache evidence dump (staged-writes crash path)

You are a mechanical lane worker. Execute the steps exactly as written, capture
outputs verbatim. If reality deviates from anything this brief states, STOP
immediately and write what you observed into REPORT.md. Do not improvise, do
not fix anything, do not investigate beyond the listed commands.

## Base verification (FIRST action, before anything else)
```bash
cd /Users/chrishafley/projects/sprefa-lane-flash-a
git merge --ff-only 92756b54dc0cb633e9636234f5358f3324be1ebf
git rev-parse HEAD
```
HEAD must print 92756b54dc0cb633e9636234f5358f3324be1ebf. If not: STOP, write
REPORT.md stating the sha you saw.

## Ownership
You may create/modify ONLY: `REPORT.md` and `lane-artifacts/` at the worktree
root. Never edit any other file. Never commit. Never push.

## Purpose (context, no action needed)
ARCH.pl task 813 records: kill -9 between a disk write and the host answer
replays the write on restart, because effect identity is content-addressed
over the DEMAND only. A proposed fix stores a disk digest on the response
side. This lane collects the evidence: what the effect_cache table actually
stores today, so the coordinator can judge whether the fix needs a schema
change.

## Step 1 — setup
```bash
mkdir -p lane-artifacts
cd v6/tsv2 && pnpm install --frozen-lockfile 2>&1 | tail -5
cd ../..
```
If pnpm install fails: STOP, paste the error into REPORT.md.

## Step 2 — exploit: full harness run, captured
```bash
bash v6/tsv2/labs/staged-writes/receipts.sh 2>&1 | tee lane-artifacts/run1.txt
```
Expected per the file header: phases 0-8 with `ok` lines; the run may print
FAIL lines only if the tree deviates from its landed state. Record the exit
code. If ANY line starts with `FAIL`: finish the capture, note it in
REPORT.md under "Deviations", and continue to step 3 (the dumps are still
wanted).

## Step 3 — exploit: dump every sqlite db the run left behind
```bash
ls -dt ${TMPDIR:-/tmp}/staged-writes.* | head -3
```
For the NEWEST directory (first line), name it WORKDIR and run:
```bash
find <WORKDIR> -name '*.db' -o -name '*.sqlite*' | tee lane-artifacts/dbs.txt
```
For EACH file listed:
```bash
sqlite3 <dbfile> '.tables'          >> lane-artifacts/schema.txt
sqlite3 <dbfile> '.schema'          >> lane-artifacts/schema.txt
sqlite3 <dbfile> 'SELECT * FROM effect_cache;' >> lane-artifacts/effect_cache_rows.txt 2>&1
```
If a db has no effect_cache table, the error line itself is the finding —
keep it in the file.

## Step 4 — explore (epsilon probe): does a trail already partially exist?
```bash
grep -n "digest\|trace\|ordinal\|wall\|elapsed\|span(" v6/tsv2/serve/main.ts > lane-artifacts/serve_trail_grep.txt
grep -rn "digest\|trace\|ordinal\|wall\|elapsed" v6/dl/src/1_hosts.ts > lane-artifacts/hosts_trail_grep.txt
```
Copy both files' contents verbatim into REPORT.md. Do not interpret them.

## REPORT.md skeleton (write exactly these sections)
```
# Lane A REPORT
## Base sha verified: <yes/no + sha printed>
## Run 1 exit code: <code>; FAIL lines: <count, paste each>
## DB files found: <paste dbs.txt>
## effect_cache schema: <paste the CREATE TABLE block or the error>
## effect_cache rows after run: <paste rows or error>
## Epsilon probe: serve_trail_grep + hosts_trail_grep verbatim
## Deviations: <anything that did not match this brief, or "none">
```
