# Planning task: CST/AST querying design for dl6

You are a planning agent working alone in this git worktree (base sha
92756b54). Deliverable: write `PLAN.md` at the worktree root. You may create
ONLY `PLAN.md` and an optional `plan-notes/` directory. Edit no other file.
Never commit or push.

## Context

sprefa v6 ("dl6") is a datalog-over-code language: prolog compiles .dl6 to
TypeScript+SQLite. We are designing first-class CST/AST querying — tree-sitter
grade structural queries expressed in harmony with the prolog/datalog surface.

Ground yourself by reading (all paths repo-relative):
- `v6/prolog/LANG.md` — language design axioms (effects = one rel; tick = one
  sqlite transaction; rx hosts the yield residue)
- `v6/dl/src/0_types.ts` — HostDef interface, Builtins (note: `extract` and
  `sg` are already HostDefs), EffectCacheRow
- `README.md` — the v5 op table: `ast` (tree-sitter queries), `match_ast`
  (ast-grep patterns), `ast_yaml` (relational inside:/has: rules), `match_line`
- `v6/tsv2/labs/staged-writes/5-span.dl6` header — the span-typed host output
  refusal (column_type_wrapper), flat start/end workaround
- `v6/prolog/ARCH.pl` lines ~812-813 — staged-writes lab findings: write
  payload is a relation but host input is a row (no string aggregate/fold
  exists yet); effect identity is demand-only
- `v6/sprefa-extract/src/types.rs` — CstF family (lossless structure plane,
  per-file JSONL, no cross-file resolution)

## The 10 open decisions (a prior analysis — challenge it where wrong)

1. CST fact schema: generic node(id,kind,span)+child(parent,child,ordinal,field)
   vs rel-per-kind vs generic+derived typed views.
2. Query surface: embedded tree-sitter query string op vs native dl6 joins vs
   S-expr sugar that LOWERS to joins at compile (parse_dl.pl DCG precedent).
3. Quantified captures (* / + yield lists; rows have no lists): explode to
   rows+ordinal vs forbid in v1 vs aggregate via a new fold (group_concat) —
   note the same fold is missing for write payloads (ARCH 813).
4. Span as a column type: lift the column_type_wrapper host-output refusal vs
   flat start/end int columns forever.
5. Extraction demand (eager per-file CstF corpus vs lazy query-demanded, where
   demand=(path,rev,lang) and extraction rides the existing extract HostDef +
   effect_cache machinery).
6. tree-sitter predicates #eq?/#match?: map them vs drop (dl6 guards subsume).
7. inside:/has: ancestor-descendant closure over child: recursion design +
   the anti-quadratic guarantee (SEARCH-not-SCAN, COUNT tests).
8. Grammar version in the fact digest (cache invalidation on tree-sitter bump).
9. Rewrite spelling: ast-grep fix: templates vs captures feeding splice rows
   through the single staged-writes path.
10. Comment/trivia plane: attached children vs separate trivia rel (markdown
    zones become trivia queries).

## Required PLAN.md structure

1. **Decision order** — which decisions gate which, as a dependency list.
2. **Per-decision ruling** — your recommended default + rationale, 3 sentences
   max each. Disagree with the list above freely; if a decision is fake or
   missing, say so and add/remove.
3. **Top 2 labs** — the two highest-information experiments to run BEFORE
   committing to the rulings; for each: hypothesis, exact method, what output
   would falsify which ruling.
4. **Risks** — top 5, each with the earliest observable symptom.
5. **What you would cut** — anything in the 10 that should not be built at all.

Write in terse engineering prose. Tables welcome. No praise, no filler.
