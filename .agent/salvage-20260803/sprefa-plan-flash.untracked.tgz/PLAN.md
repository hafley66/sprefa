# PLAN: CST/AST querying for dl6

Design for first-class structural querying on v6. Grounding established in the
worktree at base 92756b54 and the files listed below; per-rule citations are
repo-relative. This doc rules the surface, a prior 10-decision analysis is
challenged where it miskeys, and no code target is mandated.

## 0. Grounding that changes the defaults

- The lossless structure plane already exists as `CstF`: nodes carry an OPEN
  kind (interned `NameId`) + `Span{start,len}`, the one edge kind is `Child`,
  unnamed punctuation is reparented away, and the wire is per-file JSONL with
  no cross-file resolution (`v6/sprefa-extract/src/types.rs`). Any schema ruling
  that re-invents this plane misses the build the extractor already shipped.
- `node` and `child` already exist in v5 with nested-set spans: `node(id, kind,
  file, lo, hi, parent)` and `child(parent, child)` (README relation table).
  `child` is exactly two columns, so `closure(child)` is already expressible.
- dl6 storage is typed and already declined a composite: a struct `span` column
  on a HOST OUTPUT refuses with `unsupported_surface(column_type_wrapper)`
  (`v6/tsv2/labs/staged-writes/5-span.dl6`), forcing flat `start: int, end: int`.
- The aggregate that would serve quantified captures and write payloads is not
  built: `group_concat` is defect F9, compiles clean and silently stores the
  literal text (`task(group_concat_silent_miscompile)` in `v6/prolog/ARCH.pl`).
- v5 parity is the source-vs-derived split: source facts have exactly one
  support (their file), cached by (content hash, rule text), and an edit
  retracts that file and re-extracts. Derived views recompute on top.

## 1. Decision order

Dependencies, most-gating first. Anything not downstream of D1 is listed where
it attaches; D4 is decoupled and could move anywhere.

| order | decision | gates / is gated by |
|---|---|---|
| D1 | FACT SCHEMA (generic node+child plane, derived typed views) | gates every other: the base every join reads |
| D5 | EXTRACTION DEMAND (eager plane, lazy views) | gated by D1 (what is materialized); feeds D8 |
| D8 | GRAMMAR VERSION IN DIGEST (cache invalidation) | gated by D5 (it rides the extraction cache key); gates correctness of historical revs |
| D7 | ANCESTOR-OR-CONTAIN (inside:/has: decode) | gated by D1 (child shape) + the existing closure/nested-set machinery |
| D2 | QUERY SURFACE (joins native, query-string host kept for parity) | gated by D1 + D7 (the primitives must exist first) |
| D4 | SPAN (flat ints in v1) | decoupled; affects node columns and D9 rewrite precision if lifted |
| D10 | TRIVIA PLANE (separate comment rel) | gated by D1 + D5 (second projection off the same parse) |
| D9 | REWRITE (captures into splice rows, not fix templates) | gated by D2 + D4 |
| D3 | QUANTIFIED CAPTURES (explode v1; fold deferred) | gated by D2; the fold half is shared, out-of-tree, and decoupled |
| D6 | PREDICATES (#eq?#match?) | CUT, see section 5 |

## 2. Per-decision ruling

**D1-schema: generic node+child plane, typed views as rules.**
The extractor already emits exactly this plane. Store `node(id, kind, lo, hi)`
and `child(parent, child, ordinal)` as the storage schema; expose per-kind typed
rels as ordinary `rel` rules (`fn_def(...) <- node(_, "function_declaration", ...)`).
rel-per-kind as a STORAGE schema is cut: it duplicates the plane and breaks the
lossless-reparenting CstF contract. Add `ordinal` to child: the current `Child`
edge drops both field label and order (types.rs), and both are needed by
structural queries; this is the one real feed change and it is cheap.

**D5-demand: eager plane, lazy typed views.**
CstF is the base every structural rel projects from. Materialize it once per
(file, rev, lang), keyed by content hash exactly as v5 source rows are, and let
each typed view be a derived rule over it. Lazy per-query extraction re-parses
per rule and fights the source-vs-derived split that makes incrementality
tractable. This is the v5 model restated, not a new demand mode.

**D8-grammar version in digest: yes, mix it into the extraction cache key.**
The source cache keys on (content hash, rule text); a tree-sitter/grammar bump
with a stale key returns old nodes on a historical rev. Fold a grammar version
into the key (the `identity_digest`/`full_digest` mix in `EffectCacheRow` is the
seam). Without it a bump silently serves stale structure, the worst failure
class this repo keeps filing.

**D7-ancestor: nested-set interval containment, not a bespoke op.**
`node` already carries `lo, hi` (nested-set). "inside X / has subtree" decodes to
interval containment `lo_x < lo_y AND hi_y < hi_x`, an indexed range join, and is
already the closure/child path. Reuse the existing closure + nested-set columns;
do not add `inside:`/`has:` as a new grammar or op. The anti-quadratic guarantee
comes from the range index (SEARCH) on (file, lo), not from a per-query
recursive traversal.

**D2-surface: native dl6 joins are the primary surface; keep a query-string
host for v5 parity.**
The relational body with `node` + `child` predicates IS the harmonic surface
(LANG.md relational model, rules with bodies). A tree-sitter query string stays
available as a parity host (v5's `ast`), but it is a compatibility door, not the
idiom. S-expr sugar that LOWERS to joins is viable but deferred: joins are
already the spelling, and repetition evidence (the repo's own rule for sugar)
justifies nothing new until it shows up.

**D4-span: flat start/end int columns in v1; do not lift the refusal.**
The `column_type_wrapper` refusal predates AND is orthogonal to CST querying.
Span is the universal coordinate consumed by LSP and rewrite joins; turning it
into a composite column type adds plumbing for no query-side win. Keep two ints
throughout. Sugar (a `span(start,end)` struct pattern) can come later without
touching storage. This decision does not gate any other.

**D10-trivia: separate comment/trivia rel, not attached children.**
Tree-sitter skips comments; they are not CST children, so attaching them to
`child` pollutes the structural relation and breaks reparenting. Emit a separate
`comment(path, lo, hi, text, kind)` projection off the same parse (v5
`comment_node` precedent). Markdown zones and doc-comment queries ride this
plane. Two projections off one parse, not two parses.

**D9-rewrite: captures feed splice rows through the staged-writes path; no
fix-template surface.**
v5 already binds a whole-match `id` and splices a span via `gen(:replace,
lo, hi, ...)`; v6's staged-writes arc writes by byte span
(`5-span.dl6`). A rewrite is metavar captures rendered into a splice row over
that path. Do not build an ast-grep `fix:` templating surface in parallel; it
duplicates an existing write host for a convenience.

**D3-quantified captures: explode to rows+ordinal in v1; defer the fold.**
Rows have no lists, so a quantified capture (`*`/`+`) either explodes (v5
behavior: one row per occurrence) or needs an aggregate. Explode in v1; the
list-valued aggregate head is defect F9 / ARCH 813, shared with write payloads,
unbuilt, and NOT a CST decision. Ruling the fold here would hold CST hostage to
an unrelated pending aggregate. Note the two omit a shared group_concat and do
not couple their schedules.

**D6-predicates (#eq?/#match?): map-and-drop is wrong; cut is right.**
dl6 body guards (equality, regex `=~`, glob `~~`) express the same checks
structurally, so the predicates add no power to the native join surface, only to
the parity query-string host. Keep them out of v1 entirely; revisit only if a
parity diff demands them. See section 5.

## 3. Top 2 labs

Run before committing D5 and D7. They are the two ratio-bearing unknowns: plane
size and the ancestor access pattern.

**Lab A: EAGER PLANE SIZE AND INGEST COST (falsifies D5).**
- Hypothesis: full lossless `node`+`child` materialization for a kernel-size
  repo stays within an acceptable factor of today's sparse structural extraction
  (which emits only named/typed rows), so eager-and-derive holds.
- Method: build the CstF corpus for the kernel fixture two ways: (a) full
  lossless node+child as D5 proposes, (b) the current filtered projection.
  Measure ingest wall-time, fact-line count, and on-disk bytes for both. Then run
  the same three derived views (one shallow, one deep) over (a) only and record
  their eval cost.
- Falsifies: if (a) ingests 10x+ slower or 10x+ larger than (b) and the derived
  views only ever touch a thin slice, D5's eager plane is wrong and demand-driven
  extraction (filter inside the extractor before storing) wins. If (a) and (b)
  are comparable or the views dominate anyway, D5 holds.

**Lab B: NESTED-SET ANCESTOR ACCESS AND QUADRATICITY (falsifies D7).**
- Hypothesis: "inside X" via interval containment on `(file, lo)` is SEARCH and
  stays sub-quadratic, while a naive recursive-CTE ancestor walk over `child`
  degrades linearly in depth and quadratically in width on pathological files.
- Method: on real + synthetic deep/wide fixtures, materialize `child` and
  `node`, then run three ancestor queries (shallow, deep, wide). Capture
  EXPLAIN access method and row-touch count for both the containment form and a
  recursive CTE. Use COUNT assertions, not wall-clock, per the repo's
  search-not-scan standard.
- Falsifies: if containment still scans (no usable index on `(file, lo)`) or its
  row-touch grows quadratically in width/depth, then either the nested-set
  columns must be indexed differently (a reverse/range index) or a per-file size
  cap/reject must be added, and D7's "no new machinery" claim fails.

## 4. Risks

Top 5, earliest observable symptom each.

| risk | earliest symptom |
|---|---|
| Plane-size blowup: full node+child at repo scale dominates ingest/RSS | fact count and ingest wall-time jump by 10x on the kernel fixture; RSS passes budget |
| Silent wrong answers in capture/aggregate lowering (the F9 class) | a query returns fewer rows than the grammar produces, with no refusal, exactly like the group_concat miscompile |
| Ancestor quadraticity on deep/wide files | `EXPLAIN` shows SCAN not SEARCH on `(file, lo)`; deep-nest fixture stalls; COUNT fails |
| Grammar-version cache miss after a parser bump | a historical rev re-extraction returns pre-bump CST; stored nodes disagree with current grammar |
| Content-key purity break (path/rev leaking into extraction demand) | `effect_cache` `full_digest` recomputes on a rev change without content change; same bytes fire twice |

## 5. What to cut

- **D6 predicates (#eq?/#match?)** do not build in v1. The parity query-string
  host can carry them later if a diff demands; the native join surface has
  strict superiors in body guards. Remove from the decision set.
- **D9 fix-template branch** do not build ast-grep `fix:` templates. Captures
  into splice rows cover rewrite through the single existing write path.
- **D3's "aggregate via a new fold" clause** remove from THIS design. It is
  defect F9 / ARCH 813, a shared pending `group_concat` that also serves write
  payloads; it is not a CST querying decision and gating capture behavior on it
  blocks v1. Explode in v1, file the fold separately.
- **rel-per-kind storage schema (D1 option)** cut on storage; the generic
  plane plus derived views covers it and preserves CstF.
- **S-expr sugar (D2)** cut for v1. Joins are the spelling; add sugar only from
  repetition evidence, per repo doctrine.
