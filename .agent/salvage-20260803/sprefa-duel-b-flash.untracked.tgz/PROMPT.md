# Duel: CST extraction demand — eager corpus vs lazy query-demanded (Fork B)

You are a design agent working alone in this worktree (base 92756b54).
Deliverable: `DUEL.md` at the worktree root. You may create ONLY `DUEL.md`
and optional `duel-notes/`. Edit no other file in this worktree. A rival
model received this identical prompt; the two documents will be judged
against each other on verified claims and falsifiability. Never commit or
push.

## The fork

dl6 needs CST facts (node/child) for structural queries. Extraction is either:
- **EAGER**: materialize the full lossless CST plane per (file, rev, lang)
  at ingest, derived views recompute on top (the v5 source-vs-derived model).
- **LAZY**: derive demand rows cst_need(path, content_hash, lang) from query
  goals; extraction rides the existing `extract` HostDef + effect_cache
  digest machinery (`v6/dl/src/0_types.ts` — extract is already a HostDef;
  `POST /edb/file_changed` exists as the eager editor path).

## History you MUST mine before ruling (read-only, outside this worktree)

This problem was labbed hard in this project's past. Mine the archive for
real numbers and failure modes; cite file paths for every claim you take:

- `~/projects/sprefa-archive-20260701/v4/bench/` — the v4 linux bench
  programs: linux.sprf, linux-join.sprf, linux-antijoin.sprf,
  linux-called.sprf, linux-tiny-join.sprf, linux-tiny-where-mid.sprf.
  Read them; note what shapes were benchmarked.
- `~/projects/sprefa-archive-20260701/v4/perf/baseline.toml` — recorded
  baselines if present.
- `~/projects/sprefa-archive-20260701/v3/crates/effect_runtime/src/batchers/`
  — work_steal.rs, bounded_work_steal.rs, bounded_batched.rs: the
  parallel-extraction batcher era. What strategies were tried?
- Current repo `bench/`: linux-sim/ (kernel drivers subset), printk.dl,
  extract-ab.sh (A/B extraction bench, SIZES sweep), run.sh; justfile
  bench-printk targets ("v4 linux bench equivalent" comment, justfile:46).
- Current repo `chat_log/20260504.11.linux-bench-reconcile-path-collision-fix.md`
  and `chat_log/20260505.0.linux-bench-tail-sync-cap-fix.md` — what bit
  the linux bench operationally.
- `v6/sprefa-extract/src/types.rs` — CstF family: per-file JSONL, lossless,
  no cross-file resolution.
- `v6/prolog/ARCH.pl` rows ~811-813 — staged-writes/effect_cache findings.

## Required DUEL.md structure
1. **Ruling** — EAGER, LAZY, or a precise hybrid (state the exact boundary:
   what is eager, what is demanded).
2. **Archive evidence table** — claim | source path | what it says. Minimum
   5 rows from the v3/v4 archive + current bench. No claim without a path.
3. **Steelman against your ruling** — strongest concrete workload where
   your side loses.
4. **The definitive lab** — reuse the linux bench lineage (bench/linux-sim
   or a real kernel checkout): exact method, metrics (fact count, on-disk
   bytes, ingest wall, cold-query latency, effect spawn count), and the
   numeric threshold that flips your ruling.
5. **Risks** — top 3 with earliest observable symptom.

Terse engineering prose. Cite what you read. No filler.
