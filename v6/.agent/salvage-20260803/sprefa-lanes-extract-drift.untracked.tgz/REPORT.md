# Lane: extract-drift — INVESTIGATION report

Question: the `4_hosts.test.ts` golden expects 79 rows, the current binary produces 82.
What are the 3 extra rows, are they correct or a regression, and what should be done.

Verdict up front: CORRECT, additive extraction. The 3 extra rows are true facts about
`bad.ts` that the older binary did not emit. Re-baseline to 82. The pin is dead and must be
repointed.

## Reference builds (evidence basis)

- NEW binary (produces 82):
  `/Users/chrishafley/projects/sprefa/v6/sprefa-extract/target/release/extract` (built 2026-07-31).
- OLD binary (produces 79, the golden's reference): built from the reaped worktree's state,
  the `plan/extract-golden-plan` branch tip `023cd61a`
  (`2026-07-26 23:59:43 -0400 plans: bake-off reframed...`). The reaped path
  `.claude/worktrees/extract-golden-plan/v6/sprefa-extract/target/debug/extract` points at that
  branch. I exported the crate at `023cd61a` to temp and built release:
  cargo build released in 33.7s, produced exactly 79 rows on the fixture.
- Fixture `v6/dl/fixtures/corpus/bad.ts` is 6 lines, unchanged since `84744e7a`.
- No node_modules in this worktree. I ran the binaries directly by absolute path; no npm
  install was needed for the reproduction.

## A. What the 3 extra rows ARE

Sorted set diff (`comm`) of NEW vs OLD output on the fixture. 0 rows removed, 3 added:

```
{"record":"arg","family":"df","call":{"start":147,"end":167},"pos":-1,"arg":{"start":147,"end":154}}
{"record":"arg","family":"df","call":{"start":147,"end":167},"pos":0,"arg":{"start":159,"end":166}}
{"record":"param","family":"df","span":{"start":22,"end":34},"pos":0}
```

All three are `family=df` auxiliary records (`record` in {param, arg}), all on the single
call `console.log(message)` (span 147-167) and its sole parameter:

1. `param` / df, span 22-34, pos 0. Span 22-34 is `name` in `greet(name: string)`.
   Emitted by `df_seed_params` in `src/lang/ts.rs`, which mints one `DfParam{node, pos}` per
   formal parameter. `name` is the first (only) param, so pos 0.
2. `arg` / df, call 147-167, pos -1, arg 147-154. Span 147-154 is `console`, the receiver
   of `console.log`. Emitted in `df_flow_call`, receiver branch, with the -1 receiver
   convention.
3. `arg` / df, call 147-167, pos 0, arg 159-166. Span 159-166 is `message`, the first
   positional argument to `console.log`.

The count math is purely additive: 79 old + 3 = 82 new. No existing record changed or was
dropped (`comm`: only-in-OLD is empty).

## B. Why they appeared — the commit

`2faf82b1` — `2026-07-29 08:40:18 -0400`
"extract: df param/arg aux records, kotlin resolve, flat sig owner, call-site spans (codex
luna lane)".

- Not an ancestor of `023cd61a` (the worktree tip / golden's binary); ancestor of HEAD.
- Touches `v6/sprefa-extract/src/lang/ts.rs` (and go/rust/kotlin/source files), adding
  `DfParam`/`DfArg` rows in `df_seed_params` and `df_flow_call`.
- Adds a dedicated golden test `v6/sprefa-extract/tests/2_df_aux_cli.rs` with
  `tests/fixtures/df_aux/ts.jsonl` (plus rust/go/kotlin) asserting these aux records verbatim
  across all four projectors. The TS golden uses the same -1-receiver / 0-based-pos
  convention as the 3 bad.ts rows.
- Commit message calls the shapes "Additive shapes, golden_parity intact".

Four commits touch `src/lang/ts.rs` between `023cd61a` and HEAD (`e85e2274` diet resolution,
`c6e2bf7b` value-plane checkpoint, `2faf82b1`, `b1f4634c` prolog). `2faf82b1` is the one that
introduces param/arg aux; none of the others emit them.

## C. Are they correct?

YES. Each extra row is a true fact about `bad.ts`:

- `param` name@pos0: `greet` has one formal parameter named `name`. True.
- `arg` receiver console (pos -1): `console.log` has receiver `console`. True.
- `arg` message (pos 0): `console.log` has one positional argument `message`. True.

None duplicates an existing row (there were no `param`/`arg` records before; they are a
separate `record` value from `node`/`edge`). None is spurious. The old binary simply had the
aux not yet implemented (the pre-`2faf82b1` comment in `ts.rs` read "the positional
`param_pos` aux is deferred"). The newer binary correctly realizes it. This is improved
coverage, not double-counting and not an error-recovery effect. `bad.ts` is NOT malformed at
the AST level for this extractor; its "bad" rail (a leftover debug `console.log`) is what the
Cst comment row (83-144) and these arg/param rows legitimately capture.

## D. What should be done

1. Re-baseline `v6/dl/tests/4_hosts.test.ts:463` from 79 to 82. Risk: the golden is now
   coupled to the extract binary's output, which is consume-only and evolving. Every future
   additive extract change can shift the count again, re-triggering this failure. That risk
   is inherent in a raw-count golden against a live external binary.

   Lower-risk variant if the owner wants it: change the assertion from a bare
   `rows.length === 82` to a set-membership check keyed on `(record, family, kind, span)`
   (the test already JSON-parses every `record_json`), so additive aux rows stop breaking the
   gate. This is optional; the quick unblock is the count re-baseline.

2. Fix the dead pin. `ExtractBinDefault` (`v6/dl/tasks.d.ts:346-347`) and
   `DEFAULT_EXTRACT_BIN` (`v6/dl/src/1_hosts.ts:347-348`) point at
   `/Users/chrishafley/projects/sprefa/.claude/worktrees/extract-golden-plan/...`, a reaped
   worktree. Repoint both to the live build:
   `/Users/chrishafley/projects/sprefa/v6/sprefa-extract/target/release/extract` (the path
   the coordinator already uses and I verified running). `DL_EXTRACT_BIN` override stays as
   the general escape hatch. This does not touch the extract crate, so it respects the
   consume-only ruling (2026-07-24). Risk: pinning to the release build (vs the old debug
   build) is a build-profile change; debug vs release differ in optimization, not in emitted
   rows, but it is a small assumption worth noting in the commit.

## What I could not determine

Nothing material. The 3-row delta is fully accounted for by `2faf82b1` and verified
correct by the crate's own `df_aux` goldens plus direct reading of `bad.ts`. The only open
call is product-level: whether the owner wants the count golden left as-is (re-baselined to
82) or hardened to set-membership. I did not edit `tasks.d.ts`, the test, the fixture, or
the extract crate, per instructions. I built the old binary in
`/var/folders/.../T/opencode/v6/sprefa-extract` (temp clone), not in any repo tree, and left
no source changes.
