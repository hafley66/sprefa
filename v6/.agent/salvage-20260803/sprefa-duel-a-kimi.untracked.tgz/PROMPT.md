# Duel: dl6 structural-query lowering target (Fork A)

You are a design agent working alone in this worktree (base 92756b54).
Deliverable: `DUEL.md` at the worktree root. You may create ONLY `DUEL.md`
and optional `duel-notes/`. Edit no other file. A rival model received this
identical prompt; the two documents will be judged against each other on
verified claims and falsifiability. Never commit or push.

## The fork

dl6 gets S-expression structural-query sugar. It must lower to ONE of:
- **JOINS**: compile patterns to native dl6 joins over node/child rels.
  The compiler sees everything (pushdown, type plane, refusals); matching
  semantics are reimplemented in datalog.
- **STRING**: compile patterns to a tree-sitter query string handed to the
  existing extract host. Tree-sitter's matcher is bought, not rebuilt;
  the compiler goes blind past the host boundary.

## Ground truth to read first (repo-relative)
- `v6/prolog/1_host_expand.pl` lines ~150-160 and ~410-460: `ts_query/1`
  and `compile_ts_query` ALREADY compile a pattern term to query text.
  Note what `unmapped_feature` throws exist and what they imply.
- `README.md` v5 op table: `ast` (tree-sitter queries), `match_ast`,
  `ast_yaml` (inside:/has: relational rules) — the v5 parity surface.
- `README.md` lines ~505 and ~557: v5 `node(id, kind, file, lo, hi,
  parent)` has NESTED-SET spans; `child(parent, child)` is 2-col. "X inside
  Y" is interval containment, an indexed range join — no recursion.
- `v6/prolog/compile/parse_dl.pl`: the DCG precedent for parsing sugar.
- `v6/prolog/LANG.md`: effects = one rel; the sugar-with-visible-lowering
  doctrine.

## Prior arguments (challenge freely)
- Pro-JOINS: opaque strings defeat pushdown/type-plane/refusals; joins are
  already the idiom; the S-expr parser is cheap by DCG precedent.
- Pro-STRING: lowering to joins rebuilds tree-sitter matching semantics
  (anchors, quantifiers, alternations, error nodes) in datalog — a bought
  tool duplicated; ts_query/1 machinery already exists.

## Required DUEL.md structure
1. **Ruling** — JOINS or STRING or a precise hybrid (state exactly where
   the boundary sits).
2. **Steelman against your ruling** — the strongest concrete failure case
   for your side, as a specific query that hurts it.
3. **Falsifying experiment** — smallest lab that would flip your ruling:
   exact method, exact pass/fail criterion.
4. **Cost** — files touched and new machinery required for your ruling,
   grounded in the files you read (cite paths/lines).
5. **Semantics inventory** — table of tree-sitter query features (fields,
   anchors, quantifiers, alternations, wildcards, error nodes, predicates)
   x your ruling: supported how / dropped / deferred.

Terse engineering prose. Cite what you read. No filler.
