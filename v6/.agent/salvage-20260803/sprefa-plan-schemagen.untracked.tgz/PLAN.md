# PLAN: Schema facts in Prolog → generated Rust / TypeScript / SQLite (MVP)

Base: `92756b54dc0cb633e9636234f5358f3324be1ebf`.

---

## 1. Fact schema, type signatures

Source of truth: a single checked-in Prolog fact file.

```prolog
% table(TableId, SqlName, WithoutRowId).
%   TableId = ground atom used as foreign key in column/7, pk/3, fk/4.
%   SqlName = atom, the exact SQLite table name (one name, every language).
%   WithoutRowId = bool (true for composite-key junctions).

table(strings,    strings,    false).
table(repos,      repos,      false).
table(roots,      roots,      false).
table(repo_revs,  repo_revs,  false).
table(files,      files,      false).
table(revs_files, revs_files, true).
table(file_bytes, file_bytes, true).
table(node,       node,       false).
table(edge,       edge,       true).

% column(TableId, ColName, Position, SqlType, Nullable, IsPk, IsUnique, Default).
%   ColName      = atom, exact SQL column name.
%   Position     = integer (1-based, order in CREATE TABLE).
%   SqlType      = integer | text | blob.
%   Nullable     = true | false.
%   IsPk         = true | false.
%   IsUnique     = true | false  (single-column UNIQUE only).
%   Default      = none | auto_increment | expr(string).
%
% Examples (full seed in §3):
column(strings, string_id, 1, integer, false, true,  false, none).
column(strings, content,   2, text,    false, false, true,  none).

column(node, node_id,    1, integer, false, true,  false, none).
column(node, family,     2, integer, false, false, false, none).
column(node, file_id,    3, integer, false, false, false, none).
column(node, byte_start, 4, integer, false, false, false, none).
column(node, byte_len,   5, integer, false, false, false, none).
column(node, kind,       6, integer, false, false, false, none).
column(node, name_id,    7, integer, true,  false, false, none).

% pk(TableId, ColName, PkOrder).
pk(strings,    string_id, 1).
pk(revs_files, rev_id,    1).
pk(revs_files, path_string_id, 2).
pk(edge,       family,    1).
pk(edge,       src_id,    2).
pk(edge,       dst_id,    3).
pk(edge,       kind,      4).

% unique_index(Name, TableId, [ColName|Cols], WhereClause).
%   WhereClause = '' for full unique index; SQLite WHERE string for partial.
unique_index(ux_repo_revs_identity, repo_revs, [repo_id, git_sha], '').
unique_index(ux_node_identity,      node,      [family, file_id, byte_start, kind], '').
unique_index(ux_repo_revs_work_root, repo_revs, [root_id], 'kind = 1').

% fk(TableId, ColName, RefTableId, RefColName).
fk(roots,      repo_id,         repos,      repo_id).
fk(roots,      path_string_id,  strings,    string_id).
fk(repo_revs,  repo_id,         repos,      repo_id).
fk(repo_revs,  root_id,         roots,      root_id).
fk(repo_revs,  base_rev_id,     repo_revs,  rev_id).
fk(revs_files, rev_id,          repo_revs,  rev_id).
fk(revs_files, path_string_id,  strings,    string_id).
fk(revs_files, file_id,         files,      file_id).
fk(file_bytes, file_id,         files,      file_id).
fk(file_bytes, string_id,       strings,    string_id).
fk(node,       file_id,         files,      file_id).
fk(node,       name_id,         strings,    string_id).
fk(edge,       src_id,          node,       node_id).
fk(edge,       dst_id,          node,       node_id).

% logical(TableId, ColName, LogicalKind).
%   Semantic tag for future emitters (JSON-Schema format, OpenAPI, TypeSpec).
logical(strings, string_id, interned_id).
logical(strings, content,   interned_text).
logical(files,   content_hash, content_hash).
logical(repo_revs, git_sha, git_sha).
logical(node,    family,    ordinal).
logical(node,    kind,      ordinal).
logical(edge,    family,    ordinal).
logical(edge,    kind,      ordinal).

% type_map(SqlType, RustType, TsType).
type_map(integer, i64,    number).
type_map(text,    String, string).
type_map(blob,    vec_u8, uint8array).   % rendered as Vec<u8> / Uint8Array

% nullable wrapping rules (used by emitters):
%   Rust: non-null -> RustType; null -> Option<RustType>.
%   TS:   non-null -> TsType;     null -> TsType | null.
%   PK auto_increment is surfaced only in DDL/derive, not in row-load types.
```

### Emitter shape (pseudo-code)

```prolog
% v6/prolog/compile/2_emit_spine_ts.pl
%
% emit_spine_ts :-
%   findall(RowInterface, (table(Tbl, SqlName, _),
%                          interface_name(SqlName, IName),
%                          member_lines(Tbl, Members),
%                          format('export interface ~w {~n~w}~n', [IName, Members])),
%           Blocks),
%   join_blocks(Blocks, Body),
%   generated_section(BeginMarker, EndMarker, Body, Text),
%   replace_or_write(Path, Text).
%
% member_lines(Tbl, Lines) :-
%   findall(Line, (column(Tbl, Col, _, SqlType, Nullable, _, _, _),
%                  type_map(SqlType, _, TsType),
%                  ts_type(Nullable, TsType, Final),
%                  format(atom(Line), '  ~w: ~w;', [Col, Final])),
%       Lines).
%
% ts_type(false, T, T).
% ts_type(true,  T, Atom) :- atomic_list_concat([T, ' | null'], Atom).
```

```prolog
% v6/prolog/compile/2_emit_spine_rust.pl  (post-MVP)
%
% emit_spine_rust :-
%   findall(Struct, (table(Tbl, SqlName, _),
%                    rust_mod_name(SqlName, Mod),
%                    field_lines(Tbl, Fields),
%                    pk_meta(Tbl, PkMeta),
%                    derive_block(Derive, PkMeta),
%                    format('... sea-orm Model ...', [Derive, Mod, SqlName, Fields])),
%          Blocks),
%   write_file(Path, Preamble, Blocks).
%
% field_lines(Tbl, Lines) :-
%   findall(Line, (column(Tbl, Col, _, SqlType, Nullable, IsPk, _, Default),
%                  type_map(SqlType, RustType, _),
%                  rust_nullable(Nullable, RustType, Final),
%                  derive_attr(IsPk, Default, Attr),
%                  format(atom(Line), '    ~w~w\n    pub ~w: ~w,', [Attr, nl, Col, Final])),
%       Lines).
```

### SQLite ⟷ Rust ⟷ TypeScript mapping

| SQLite | Rust (row-load) | TypeScript (row-load) | notes |
|---|---|---|---|
| `INTEGER NOT NULL` | `i64` | `number` | PKs render same; `auto_increment` is DDL-only |
| `INTEGER` (nullable) | `Option<i64>` | `number \| null` | FK columns |
| `TEXT NOT NULL` | `String` | `string` | |
| `BLOB NOT NULL` | `Vec<u8>` | `Uint8Array` | `content_hash` |
| `BLOB` (nullable) | `Option<Vec<u8>>` | `Uint8Array \| null` | `git_sha` |

Composite keys (`revs_files`, `file_bytes`, `edge`) are `WITHOUT ROWID`; the row-load type still lists every column, PKs included.

---

## 2. MVP slice

**Chosen:** (a) emit TypeScript row interfaces into a marker section of `v6/sprefa-store/js/src/engine/types.ts` + staleness test vs the fact file.

Justification: it retires the only duplicated row-type twin that both sides already depend on (`NodeRow`/`EdgeRow`/`SpanRow` in `types.ts`, plus the seven entity row interfaces in `spine.ts`); it is pure code generation, touches no runtime paths; and a marker-section staleness test is exactly the existing repo pattern (`0_inventory.ts`, `SYNTAX.md`).

**The staleness gate (CI-runnable):**

```
swipl -q -l v6/prolog/compile/2_emit_spine_ts.pl \
  -g 'emit_spine_ts:spine_ts_text(Text),format("~s",[Text])' -g halt \
  > /tmp/spine_types_generated.txt

# compare the generated marker block to the checked-in block in types.ts
node v6/sprefa-store/js/tests/schema/spineTypesStale.test.ts
```

Test logic:
1. Run the Prolog emitter and capture only the `<!-- BEGIN GENERATED SPINE ROW TYPES -->` … `<!-- END GENERATED SPINE ROW TYPES -->` block.
2. Read `v6/sprefa-store/js/src/engine/types.ts` and extract the same marker block.
3. `assert.equal(generated, checkedIn)`.

This is the exact test that proves the hand-kept TS row types have not drifted from the canonical Prolog facts. It can be added to `v6/sprefa-store/js/tests/engine/spineTypesStale.test.ts` and run with the package test runner.

---

## 3. Seeding

**Recommended:** hand-transcribe the 9 tables from `v6/sprefa-store/src/spine.rs` into the fact file once.

Reason: there are only ~22 columns total; a macro/AST harvester would require new tooling and parsing of SeaORM derives for a one-time gain. The fact file is the canonical contract, not a derived artifact. After MVP, optional: write a one-off `sprefa-extract` query set to cross-check the fact file against `spine.rs`, but the human-readable fact file remains the source of truth.

---

## 4. Instance lifetimes / storage layout

| artifact | path | checked in? | notes |
|---|---|---|---|
| Canonical fact file | `v6/prolog/schema/spine_schema.pl` | yes | The source of truth. Hand-edited for schema changes. |
| TS emitter | `v6/prolog/compile/2_emit_spine_ts.pl` | yes | Consumes `spine_schema.pl`. |
| Rust emitter (post-MVP) | `v6/prolog/compile/2_emit_spine_rust.pl` | yes | Consumes same facts. |
| Generated TS block | marker section in `v6/sprefa-store/js/src/engine/types.ts` | yes | Regenerated by emitter; staleness test guards drift. |
| Staleness test | `v6/sprefa-store/js/tests/engine/spineTypesStale.test.ts` | yes | Runs in CI. |
| DDL emitter (post-MVP) | `v6/prolog/compile/2_emit_spine_ddl.pl` | yes | Generates canonical `CREATE TABLE` + indexes; can replace hand-written DDL in `spine.ts`. |

No `_auto` suffix is required because the file is a manual file with a generated *section*, following the `SYNTAX.md` / `0_inventory.ts` precedent rather than the Hafley TypeSpec route-file convention.

---

## 5. N-language stage-setting

What must be correct now so future emitters bolt on without a fact-schema migration:

1. **One name, every target:** `table/2` and `column/2` use the exact SQL identifier; emitters derive language-specific spellings mechanically, never rename.
2. **Separate structural facts from rendering facts:** `column/8` stores SQL type/nullability/PK/unique/default; `type_map/3` stores the per-language mapping. Adding a target means adding a `type_map` column, not changing `column/8`.
3. **Logical tags now:** `logical/3` records `interned_id`, `ordinal`, `content_hash`, `git_sha`, etc., so JSON-Schema/OpenAPI/TypeSpec emitters know formats and constraints without inferring them from column names.
4. **Indexes are first-class:** `unique_index/4` carries partial-index `WHERE` clauses; future emitters can render them as SQL, OpenAPI unique constraints, or validation rules.
5. **FKs are explicit:** `fk/4` lets future emitters emit relation navigation, GraphQL edges, or SeaORM relation enums without parsing comments.
6. **No generated values in the fact file:** `auto_increment` is in `Default`, not encoded as a special Rust derive fact; keeps the schema language-neutral.

---

## 6. Buy check

| tool | what it would replace | why Prolog wins / loses |
|---|---|---|
| `sea-orm-cli entity generate` | Rust `DeriveEntityModel` structs + DDL | Loses for this project: it needs a live DB or SQL input and emits opinionated code; it cannot also emit TS row interfaces; it does not preserve the exact `WITHOUT ROWID`/partial-index choices already validated. Prolog keeps the source of truth in a checked-in fact file and emits both targets. |
| `openapi-typescript` | TS types from an OpenAPI spec | Loses: it is spec→TS only; there is no canonical OpenAPI description of the SQLite spine today, and shoehorning DDL into OpenAPI is more work than a direct fact→TS emitter. Prolog is one step, no intermediate spec. |
| `alloy` (progenitor / Rust OpenAPI bindings) | Rust client/structs from OpenAPI | Loses: same problem — no OpenAPI seam, and it would not cover TS or the DDL. Prolog is cheaper and target-agnostic. |

For a multi-language boundary type system (HTTP/WebSocket) the Hafley TypeSpec → N-emitters architecture is the right prior art; for the *SQLite storage spine*, a small Prolog fact base is the cheaper single source of truth because the schema is closed, small, and already expressed as relations.

---

## 7. Effort

| step | files touched | LOC est | notes |
|---|---|---|---|
| 1. Create fact file `v6/prolog/schema/spine_schema.pl` (9 tables, columns, PKs, FKs, indexes, logical tags) | new: `v6/prolog/schema/spine_schema.pl` | ~120 | Hand-transcribed from `spine.rs`. |
| 2. TS emitter `v6/prolog/compile/2_emit_spine_ts.pl` | new: `v6/prolog/compile/2_emit_spine_ts.pl` | ~90 | Generates marker section only. |
| 3. Add marker section to `types.ts`, move row interfaces out of `spine.ts` | edit: `types.ts`, `spine.ts` | ~40 | Delete 7 hand-kept interfaces from `spine.ts`; import from `types.ts`. |
| 4. Staleness test `spineTypesStale.test.ts` | new: `v6/sprefa-store/js/tests/engine/spineTypesStale.test.ts` | ~50 | Direct equality of generated block to checked-in block. |
| 5. Run gate locally, regenerate, commit generated section | edit: `types.ts` | 0 | Emitter output becomes the checked-in block. |
| 6. (Optional post-MVP) Rust emitter `2_emit_spine_rust.pl` + parity test | new: `2_emit_spine_rust.pl`, test | ~120 | Validates generated Rust fields against `spine.rs` by `cargo test` or text compare. |
| 7. (Optional post-MVP) DDL emitter + parity test vs `create_table_from_entity` | new: `2_emit_spine_ddl.pl`, test | ~100 | Generates SQL; compares to SeaORM output. |

**MVP gate:** steps 1–5. Total new/edited LOC ~300, mostly data and a small emitter.

**Ordered steps:**
1. Seed `spine_schema.pl` from `spine.rs`.
2. Write `2_emit_spine_ts.pl`.
3. Add marker section to `types.ts`, remove duplicate row interfaces from `spine.ts`.
4. Write `spineTypesStale.test.ts`.
5. Run emitter, run test, check in regenerated `types.ts` block.
