# Lane B: harness determinism diff (does writing end byte grading?)

You are a mechanical lane worker. Execute the steps exactly as written, capture
outputs verbatim. If reality deviates from anything this brief states, STOP
immediately and write what you observed into REPORT.md. Do not improvise, do
not fix anything, do not investigate beyond the listed commands.

## Base verification (FIRST action, before anything else)
```bash
cd /Users/chrishafley/projects/sprefa-lane-flash-b
git merge --ff-only 92756b54dc0cb633e9636234f5358f3324be1ebf
git rev-parse HEAD
```
HEAD must print 92756b54dc0cb633e9636234f5358f3324be1ebf. If not: STOP, write
REPORT.md stating the sha you saw.

## Ownership
You may create/modify ONLY: `REPORT.md`, `lane-artifacts/`, and the single
patch in step 4 to `v6/tsv2/labs/staged-writes/zone.py` (reverted in step 5).
Never edit any other file. Never commit. Never push.

## Purpose (context, no action needed)
ARCH.pl task 813 claims writing "ends byte grading" because effect wall time
enters the tick log. The coordinator's counter-claim: harness output may be
deterministic modulo paths/pids/timings. This lane measures which lines
actually differ across identical runs, and what one slow write changes.

## Step 1 — setup
```bash
mkdir -p lane-artifacts
cd v6/tsv2 && pnpm install --frozen-lockfile 2>&1 | tail -5
cd ../..
```
If pnpm install fails: STOP, paste the error into REPORT.md.

## Step 2 — exploit: two identical runs
```bash
bash v6/tsv2/labs/staged-writes/receipts.sh 2>&1 | tee lane-artifacts/run1.txt
bash v6/tsv2/labs/staged-writes/receipts.sh 2>&1 | tee lane-artifacts/run2.txt
diff lane-artifacts/run1.txt lane-artifacts/run2.txt > lane-artifacts/diff12.txt
```
Record both exit codes and the diff line count.

## Step 3 — exploit: classify every differing line
For each line in diff12.txt that starts with `<` or `>`, classify by first
matching rule:
- contains `staged-writes.` or `/tmp` or `TMPDIR` -> PATH
- contains `pid` or matches a bare number where run1/run2 differ only in
  digits -> PID_OR_TIMING
- contains `ms` or `elapsed` or `sec` -> TIMING
- anything else -> OTHER
Write the counts per class into REPORT.md and paste EVERY line classified
OTHER verbatim. If OTHER is nonempty, that is the finding; do not explain it.

## Step 4 — explore (epsilon probe): one slow write
Apply exactly this change to `v6/tsv2/labs/staged-writes/zone.py`: find the
line `def cmd_put(` and insert as the FIRST line of that function body:
```python
    import time; time.sleep(0.3)
```
If there is no function whose def line starts with `def cmd_put(`: STOP,
report the list of `def ` lines you do see, and skip to REPORT.md.
Then:
```bash
bash v6/tsv2/labs/staged-writes/receipts.sh 2>&1 | tee lane-artifacts/run3_slow.txt
diff lane-artifacts/run1.txt lane-artifacts/run3_slow.txt > lane-artifacts/diff13.txt
```
Classify diff13.txt with the same rules as step 3.

## Step 5 — revert the probe
```bash
git checkout -- v6/tsv2/labs/staged-writes/zone.py
git status --porcelain
```
Paste the git status output into REPORT.md (it must show no modification to
zone.py).

## REPORT.md skeleton (write exactly these sections)
```
# Lane B REPORT
## Base sha verified: <yes/no + sha printed>
## Exit codes: run1 <c>, run2 <c>, run3_slow <c>
## diff12 classification: PATH <n> PID_OR_TIMING <n> TIMING <n> OTHER <n>
## diff12 OTHER lines verbatim: <paste or "none">
## diff13 classification: PATH <n> PID_OR_TIMING <n> TIMING <n> OTHER <n>
## diff13 OTHER lines verbatim: <paste or "none">
## zone.py reverted: <git status output>
## Deviations: <anything that did not match this brief, or "none">
```
