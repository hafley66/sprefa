# CST/AST querying design for dl6

Base: `92756b54`. Scope: first-class, tree-sitter-grade structural queries in dl6. This plan rules the ten open decisions and names what to cut.

## 1. Decision order (dependencies)

| order | decision | gated by | gates |
|-------|----------|----------|-------|
| 1 | CST fact schema | — | 5, 7, 10 |
| 4 | Span column type | — | 9 |
| 5 | Extraction demand | 1 | 2, 3, 8 |
| 2 | Query surface | 1, 5 | 6, 7 |
| 6 | tree-sitter predicates | 2 | — |
| 3 | Quantified captures | 2, 5 | — |
| 7 | `inside:` / `has:` closure | 1, 2 | — |
| 8 | Grammar version in digest | 5 | — |
| 10 | Comment/trivia plane | 1 | — |
| 9 | Rewrite spelling | 4 | frontier |

## 2. Per-decision ruling

1. **CST fact schema — generic `node` + `child` with span identity.** Use `node(path, start, end, kind, name)` and `child(path, parent_start, parent_end, child_start, child_end, ordinal, field)`. It matches the existing spine `node`/`edge` rels and CstF's span-keyed nodes, avoids DDL churn from the open grammar vocabulary, and lets typed views be ordinary derived rels later.

2. **Query surface — S-expr sugar that lowers to a tree-sitter query string, sent to the existing `extract` host.** Keep the raw string as an escape hatch. The `ts_query/1` term form already exists in the prolog compiler; lowering it to joins would rebuild tree-sitter semantics in datalog, which duplicates a bought tool and cannot cleanly support regex predicates or quantifiers. Native joins over `node`/`child` are supported for simple structural walks but are not the primary tree-sitter-grade path.

3. **Quantified captures — explode to rows with ordinal.** Each captured node becomes a row `(path, query_id, match_id, capture, ordinal, start, end, text)`. This preserves dl6's row-only model and avoids the missing list/fold machinery; `group_concat` is rejected for v1 because it loses node identity and is currently a silent miscompile.

4. **Span column type — flat `start`/`end` ints; refuse `span` as a column type at load.** The type plane has no struct columns yet, and a one-off `span` type would become a backward-compatibility burden when struct-as-rows lands. Flat ints are already proven in `v6/tsv2/labs/staged-writes/5-span.dl6`.

5. **Extraction demand — lazy, query-demanded via the `extract` host and effect_cache.** Derive `cst_need(path, content_hash, lang)` from query goals. It matches v6's cold-by-default model and avoids extracting unqueried files; `POST /edb/file_changed` stays as a separate eager path for editor-driven re-extraction.

6. **tree-sitter predicates `#eq?` / `#match?` — pass them through in the query string.** Tree-sitter evaluates regex and equality more efficiently than SQLite post-filtering. dl6 guards can still filter capture rows when the query string is intentionally permissive.

7. **`inside:` / `has:` closure — recursive `ancestor` / `descendant` rules over `child`.** Add composite indexes on `(path, parent_start, parent_end, child_start, child_end)` and `(path, child_start, child_end, parent_start, parent_end)`. Arbitrary-depth containment is not expressible in a single tree-sitter query, and a recursive CTE seeded at a bound path uses SEARCH on the touched subtree. Restrict to path-bound seeds in v1.

8. **Grammar version in the digest — include it in `cst_need` and query-host demand identity.** Use the extract crate / tree-sitter grammar ABI hash as an input column. Same content must re-extract after a grammar bump, and the effect_cache identity/supersession machinery is the right seam.

9. **Rewrite spelling — defer rewrite out of the CST/AST query v1.** If forced earlier, emit splice rows `(path, start, end, text)` from captures, not ast-grep templates. Templates are sugar over the same byte-span writes, and the staged-writes path already consumes `(path, start, end, text)` but lacks a string fold, so rewrites cannot be ordered or batched correctly today.

10. **Comment/trivia plane — comments are ordinary named CstF nodes.** No separate trivia rel in v1. Tree-sitter emits comments as named nodes, so the generic `node`/`child` schema handles them; a separate trivia plane is reserved for doc-format extraction (markdown zones), which is a different family.

## 3. Top 2 labs (run before locking the rulings)

### Lab A — Lazy CST extraction demand

- **Hypothesis.** Deriving `cst_need(path, content_hash, lang)` from query goals and feeding it through the `extract` host lands results within one extra tick and avoids extracting unqueried files.
- **Method.** In a branch, replace eager `file_changed` extraction for a fixture corpus with a demand rule seeded by a query over `node`/`child`. Run the query against 10 files where only 2 match; count effect spawns, ticks, and cold latency.
- **Falsifies.** If the query returns zero rows on the first tick (demand not propagated), or if effect count/latency is worse than eager `file_changed`, then switch ruling #5 to eager per-file CST corpus extraction.

### Lab B — Quantified capture explosion

- **Hypothesis.** Tree-sitter `*`/`+` captures can be flattened into rows `(match_id, capture, ordinal, start, end, text)` deterministically without combinatorial blow-up.
- **Method.** Build a host harness that runs a pattern containing `+` over a fixture file; compare emitted rows to tree-sitter's JSON match output; measure row count for a file with ~100 sibling nodes.
- **Falsifies.** If ordinals are unstable across equivalent parses, or if row count is not `O(captured nodes)` (e.g., `O(matches × captures²)`), then change ruling #3 to forbid `*`/`+` captures in v1 and require explicit child-list joins.

## 4. Risks

| # | risk | earliest observable symptom |
|---|------|-----------------------------|
| 1 | Demand does not propagate to `cst_need` for transitively reached files. | Cold query returns empty; `__req_extract` rows are absent in the trace. |
| 2 | Grammar version is omitted from the effect identity. | Grammar bump tests pass locally but parity golden drifts in CI; stale CST rows served from cache. |
| 3 | Quantified capture explosion or misordered ordinals. | Query with `+` capture on a large file OOMs or emits duplicate rows; `EXPLAIN` shows a cross-product. |
| 4 | Recursive `ancestor` closure scans the full `child` table. | `EXPLAIN` lists `SCAN` on `child`; latency grows superlinearly with file size. |
| 5 | `span` column type is admitted before struct-as-rows lands. | Bridge accepts a `span` column but runtime maps it to renamed ints or host output is dropped, repeating `host_column_shadows_runtime`. |

## 5. What to cut

- **Rewrite (#9)** from the CST/AST query v1. It depends on the missing string fold and staged-writes ordering; track it as a separate staged-writes epic.
- **Rel-per-kind CST schema (#1 option).** Generic `node`/`child` is sufficient; do not build per-grammar-kind relations.
- **Separate trivia rel for source comments (#10 option).** Defer to doc-format extraction; comments live in the CST node plane.
- **S-expr lowering to joins (#2 option)** as the primary surface. Keep it only as a later lab; v1 lowers S-expr to a tree-sitter query string.
